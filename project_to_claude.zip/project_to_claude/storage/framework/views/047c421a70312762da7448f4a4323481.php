<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
      x-data="{ dark: localStorage.getItem('theme') === 'dark' }"
      x-init="
        $watch('dark', v => {
          localStorage.setItem('theme', v ? 'dark' : 'light');
          document.documentElement.classList.toggle('dark', v);
        });
        document.documentElement.classList.toggle('dark', dark);
      "
      :class="{ 'dark': dark }">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased bg-gray-100 dark:bg-slate-900 transition-colors duration-200">
        <div class="min-h-screen bg-gray-100 dark:bg-slate-900">
            <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <?php if(auth()->guard()->check()): ?>
            <?php
                $upcoming24h = \App\Models\Appointment::with(['doctor','patient'])
                    ->where(function($q) {
                        $user = auth()->user();
                        if ($user->role === 'patient') {
                            $q->where('patient_id', $user->id);
                        } elseif ($user->role === 'medecin') {
                            $q->where('doctor_id', $user->id);
                        }
                        // secretaire sees all
                    })
                    ->whereIn('status', ['en_attente', 'confirme'])
                    ->where('appointment_date', '>', now())
                    ->where('appointment_date', '<=', now()->addHours(24))
                    ->orderBy('appointment_date')
                    ->get();
            ?>
            <?php if($upcoming24h->count() > 0): ?>
                <div class="bg-amber-50 dark:bg-amber-900/30 border-b border-amber-200 dark:border-amber-700/50 px-4 py-2.5">
                    <div class="max-w-7xl mx-auto flex items-start gap-3">
                        <span class="mt-0.5 flex-shrink-0">
                            <svg class="w-5 h-5 text-amber-600 dark:text-amber-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                            </svg>
                        </span>
                        <div class="flex-1 text-sm text-amber-800 dark:text-amber-300">
                            <strong><?php echo e($upcoming24h->count()); ?> rendez-vous dans moins de 24h :</strong>
                            <span class="ml-1">
                                <?php $__currentLoopData = $upcoming24h; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $dt = \Carbon\Carbon::parse($r->appointment_date); ?>
                                    <?php if(auth()->user()->role === 'patient'): ?>
                                        Dr. <?php echo e($r->doctor->name); ?> à <?php echo e($dt->format('H:i')); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                    <?php else: ?>
                                        <?php echo e($r->patient_display_name); ?> à <?php echo e($dt->format('H:i')); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php endif; ?>

            <?php if(isset($header)): ?>
                <header class="bg-white dark:bg-slate-800 shadow dark:shadow-slate-700/30">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <main><?php echo e($slot); ?></main>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\YouBitech\Desktop\studies\annee3\S6\php\projet\Projet-Gestion-Application-Medical\resources\views/layouts/app.blade.php ENDPATH**/ ?>