<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-8 bg-white dark:bg-gray-900 min-h-screen font-sans text-gray-900 dark:text-gray-100 transition-colors duration-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            <!-- EN-TÊTE -->
            <div class="mb-8 mt-4">
                <h1 class="text-3xl font-semibold text-gray-900 dark:text-gray-100">Bonjour, Dr. <?php echo e(Auth::user()->name); ?></h1>
                <p class="text-gray-500 dark:text-gray-400 mt-1">
                    <?php echo e(\Carbon\Carbon::now()->translatedFormat('l d F Y')); ?> — voici un résumé de votre activité
                </p>
            </div>

            <!-- STATISTIQUES -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-[#F8F7F4] dark:bg-gray-800 rounded-2xl p-6">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">RDV aujourd'hui</p>
                    <p class="text-3xl font-semibold text-gray-900 dark:text-gray-100 mb-1"><?php echo e($nbRdvAujourdhui ?? 0); ?></p>
                    <p class="text-gray-500 dark:text-gray-400 text-sm">consultations prévues</p>
                </div>
                <div class="bg-[#F8F7F4] dark:bg-gray-800 rounded-2xl p-6">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Patients total</p>
                    <p class="text-3xl font-semibold text-gray-900 dark:text-gray-100 mb-1"><?php echo e($nbPatients ?? 0); ?></p>
                    <p class="text-gray-500 dark:text-gray-400 text-sm">dans votre liste</p>
                </div>
                <div class="bg-[#F8F7F4] dark:bg-gray-800 rounded-2xl p-6">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">En attente</p>
                    <p class="text-3xl font-semibold text-gray-900 dark:text-gray-100 mb-1"><?php echo e($nbEnAttente ?? 0); ?></p>
                    <p class="text-gray-500 dark:text-gray-400 text-sm">demandes à confirmer</p>
                </div>
                <div class="bg-[#F8F7F4] dark:bg-gray-800 rounded-2xl p-6">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Ordonnances</p>
                    <p class="text-3xl font-semibold text-gray-900 dark:text-gray-100 mb-1"><?php echo e($nbOrdonnances ?? 0); ?></p>
                    <p class="text-gray-500 dark:text-gray-400 text-sm">émises ce mois</p>
                </div>
            </div>

            <!-- CONTENU PRINCIPAL -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

                <!-- COLONNE GAUCHE -->
                <div class="lg:col-span-2 space-y-8">

                    <!-- RDV du jour -->
                    <div class="border border-gray-200 dark:border-gray-700 rounded-2xl p-6 dark:bg-gray-800/50">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-lg font-semibold dark:text-gray-100">Rendez-vous du jour</h2>
                            <a href="<?php echo e(route('medecin.agenda')); ?>"
                                class="text-blue-600 text-sm font-medium hover:underline">Voir l'agenda</a>
                        </div>

                        <div class="space-y-6">
                            <?php $__empty_1 = true; $__currentLoopData = $rdvAujourdhui ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div
                                    class="flex items-center justify-between pb-6 border-b border-gray-100 dark:border-gray-700 last:border-0 last:pb-0">
                                    <div class="flex items-center gap-4">
                                        <div
                                            class="bg-[#EEF4FF] dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-xl p-3 flex flex-col items-center justify-center w-14 h-14">
                                            <span class="text-lg font-bold leading-none"><?php echo e($rdv['heure']); ?></span>
                                        </div>
                                        <div>
                                            <p class="font-semibold text-gray-900 dark:text-gray-100 text-base"><?php echo e($rdv['patient']); ?></p>
                                            <p class="text-gray-500 dark:text-gray-400 text-sm"><?php echo e($rdv['motif']); ?></p>
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <?php if($rdv['statut'] === 'confirmé'): ?>
                                            <span
                                                class="bg-[#E6F6ED] text-[#0A7B45] text-xs font-semibold px-2.5 py-1 rounded-full">Confirmé</span>
                                        <?php else: ?>
                                            <span
                                                class="bg-yellow-50 text-yellow-700 text-xs font-semibold px-2.5 py-1 rounded-full">En
                                                attente</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center py-10 bg-gray-50 dark:bg-gray-800 rounded-xl border border-dashed border-gray-300 dark:border-gray-600">
                                    <svg class="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                    <p class="text-gray-500 dark:text-gray-400 font-medium">Aucun rendez-vous prévu aujourd'hui.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Derniers patients -->
                    <div class="border border-gray-200 dark:border-gray-700 rounded-2xl p-6 dark:bg-gray-800/50">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-lg font-semibold dark:text-gray-100">Derniers patients consultés</h2>
                            <a href="<?php echo e(route('medecin.agenda')); ?>"
                                class="text-blue-600 text-sm font-medium hover:underline">Voir tous</a>
                        </div>
                        <ul class="space-y-4">
                            <?php $__empty_1 = true; $__currentLoopData = $derniersPatients ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li
                                    class="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-700 last:border-0 last:pb-0">
                                    <div class="flex items-center gap-3">
                                        <div
                                            class="w-9 h-9 rounded-full bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 flex items-center font-semibold text-sm justify-center">
                                            <?php echo e(strtoupper(substr($patient['nom'], 0, 1))); ?>

                                        </div>
                                        <div>
                                            <p class="font-medium text-gray-900 dark:text-gray-100 text-sm"><?php echo e($patient['nom']); ?></p>
                                            <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($patient['date_derniere_visite']); ?></p>
                                        </div>
                                    </div>
                                    <a href="#" class="text-xs text-blue-600 hover:underline">Dossier</a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-gray-500 dark:text-gray-400 text-sm text-center py-4">Aucun patient récent.</p>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <!-- COLONNE DROITE -->
                <div class="space-y-8">

                    <!-- Raccourcis -->
                    <div class="border border-gray-200 dark:border-gray-700 rounded-2xl p-6 dark:bg-gray-800/50">
                        <h2 class="text-lg font-semibold mb-6 dark:text-gray-100">Raccourcis</h2>
                        <div class="grid grid-cols-2 gap-4">
                            <a href="<?php echo e(route('medecin.agenda')); ?>"
                                class="block bg-[#F8F7F4] dark:bg-gray-700 rounded-xl p-4 hover:bg-gray-100 dark:hover:bg-gray-600 transition">
                                <div
                                    class="bg-white dark:bg-gray-800 w-8 h-8 rounded-lg shadow-sm flex items-center justify-center mb-3">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                </div>
                                <h3 class="font-semibold text-gray-900 dark:text-gray-100 text-sm">Mon agenda</h3>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Gérer les créneaux</p>
                            </a>
                            <a href="#" class="block bg-[#F8F7F4] dark:bg-gray-700 rounded-xl p-4 hover:bg-gray-100 dark:hover:bg-gray-600 transition">
                                <div
                                    class="bg-white dark:bg-gray-800 w-8 h-8 rounded-lg shadow-sm flex items-center justify-center mb-3">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                    </svg>
                                </div>
                                <h3 class="font-semibold text-gray-900 dark:text-gray-100 text-sm">Ordonnances</h3>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Rédiger / envoyer</p>
                            </a>
                            <a href="#" class="block bg-[#F8F7F4] dark:bg-gray-700 rounded-xl p-4 hover:bg-gray-100 dark:hover:bg-gray-600 transition">
                                <div
                                    class="bg-white dark:bg-gray-800 w-8 h-8 rounded-lg shadow-sm flex items-center justify-center mb-3">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                </div>
                                <h3 class="font-semibold text-gray-900 dark:text-gray-100 text-sm">Patients</h3>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Voir les dossiers</p>
                            </a>
                            <a href="<?php echo e(route('medecin.agenda')); ?>"
                                class="block bg-[#F8F7F4] dark:bg-gray-700 rounded-xl p-4 hover:bg-gray-100 dark:hover:bg-gray-600 transition">
                                <div
                                    class="bg-white dark:bg-gray-800 w-8 h-8 rounded-lg shadow-sm flex items-center justify-center mb-3">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                                    </svg>
                                </div>
                                <h3 class="font-semibold text-gray-900 dark:text-gray-100 text-sm">Statistiques</h3>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Activité du mois</p>
                            </a>
                        </div>
                    </div>

                    <!-- Notifications -->
                    <div class="border border-gray-200 dark:border-gray-700 rounded-2xl p-6 dark:bg-gray-800/50">
                        <h2 class="text-lg font-semibold mb-6 dark:text-gray-100">Notifications</h2>
                        <ul class="space-y-4">
                            <?php $__empty_1 = true; $__currentLoopData = $notifications ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="relative pl-6 pb-4 border-b border-gray-100 dark:border-gray-700 last:border-0 last:pb-0">
                                    <span class="absolute left-0 top-1.5 w-2.5 h-2.5 bg-blue-500 rounded-full"></span>
                                    <p class="text-sm font-medium text-gray-900 dark:text-gray-100"><?php echo e($notif['message']); ?></p>
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo e($notif['date']); ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-gray-500 dark:text-gray-400 text-sm text-center py-4">Aucune notification.</p>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\YouBitech\Desktop\studies\annee3\S6\php\projet\Projet-Gestion-Application-Medical\resources\views/medecin/dashboard.blade.php ENDPATH**/ ?>