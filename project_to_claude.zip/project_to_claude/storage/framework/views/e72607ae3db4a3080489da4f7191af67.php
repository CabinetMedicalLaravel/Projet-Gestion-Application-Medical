<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<style>
    :root { --purple: #7F77DD; --purple-dark: #534AB7; --purple-light: #7F77DD1a; --bg: #F4F8FB; }
    .rdv-page { background: var(--bg); min-height: calc(100vh - 64px); padding: 2.5rem 1.5rem; font-family: 'DM Sans', sans-serif; }
    .rdv-wrap { max-width: 1100px; margin: 0 auto; }

    .rdv-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
    .rdv-title { font-family: 'Playfair Display', serif; font-size: 1.6rem; font-weight: 500; color: #111; letter-spacing: -.3px; }
    .rdv-sub { font-size: 13px; color: #6b7280; margin-top: .2rem; }

    .rdv-btn-primary {
        display: inline-flex; align-items: center; gap: .5rem;
        background: linear-gradient(135deg, var(--purple), var(--purple-dark));
        color: white; padding: .7rem 1.4rem; border-radius: 10px;
        font-size: 13.5px; font-weight: 500; text-decoration: none;
        transition: transform .15s, box-shadow .15s; border: none; cursor: pointer;
    }
    .rdv-btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 18px #7F77DD40; }

    .rdv-card { background: white; border-radius: 16px; border: 0.5px solid #e5e7eb; padding: 1.5rem; margin-bottom: 1.25rem; }

    .rdv-filter { display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-end; }
    .rdv-filter label { display: block; font-size: 11px; font-weight: 500; text-transform: uppercase; letter-spacing: .4px; color: #6b7280; margin-bottom: .35rem; }
    .rdv-filter select, .rdv-filter input[type=month] {
        border: 0.5px solid #e5e7eb; border-radius: 10px; padding: .65rem 1rem;
        font-size: 13px; color: #111; background: #f9fafb; outline: none;
        font-family: 'DM Sans', sans-serif; transition: border .18s, box-shadow .18s;
    }
    .rdv-filter select:focus, .rdv-filter input:focus {
        border-color: var(--purple); box-shadow: 0 0 0 3px var(--purple-light);
    }

    .doctor-banner {
        background: linear-gradient(135deg, var(--purple), var(--purple-dark));
        border-radius: 14px; padding: 1.1rem 1.5rem;
        display: flex; align-items: center; gap: 1rem; margin-bottom: 1.25rem; color: white;
    }
    .doctor-avatar {
        width: 44px; height: 44px; border-radius: 50%;
        background: rgba(255,255,255,.2); display: flex; align-items: center;
        justify-content: center; font-size: 1.2rem; font-weight: 700;
    }
    .doctor-name { font-weight: 600; font-size: 1rem; }
    .doctor-role { font-size: 12px; opacity: .75; margin-top: .1rem; }

    .legend { display: flex; gap: 1.25rem; margin-bottom: 1rem; font-size: 12.5px; color: #6b7280; }
    .legend span { display: flex; align-items: center; gap: .4rem; }
    .leg-dot { width: 10px; height: 10px; border-radius: 3px; display: inline-block; }
    .leg-green { background: #d1fae5; border: 1px solid #6ee7b7; }
    .leg-red   { background: #fee2e2; border: 1px solid #fca5a5; }

    .cal-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; }
    .cal-day { background: white; border-radius: 14px; border: 0.5px solid #e5e7eb; overflow: hidden; }
    .cal-day-head { background: #f9fafb; border-bottom: 0.5px solid #e5e7eb; padding: .75rem 1rem; }
    .cal-day-name { font-weight: 600; font-size: 13px; color: #111; text-transform: capitalize; }
    .cal-day-date { font-size: 11.5px; color: #6b7280; margin-top: .1rem; }
    .cal-slots { padding: .6rem; display: grid; grid-template-columns: 1fr 1fr; gap: .35rem; }

    .slot-free {
        text-align: center; font-size: 12px; font-weight: 500;
        padding: .4rem .2rem; border-radius: 7px;
        background: #d1fae5; color: #065f46; border: 0.5px solid #6ee7b7;
        text-decoration: none; transition: all .15s;
    }
    .slot-free:hover { background: #a7f3d0; transform: translateY(-1px); }
    .slot-taken {
        text-align: center; font-size: 12px; font-weight: 500;
        padding: .4rem .2rem; border-radius: 7px;
        background: #fee2e2; color: #b91c1c; border: 0.5px solid #fca5a5;
        text-decoration: line-through; cursor: not-allowed;
    }

    .rdv-success { background: #ecfdf5; border: 0.5px solid #6ee7b7; color: #065f46; border-radius: 10px; padding: .75rem 1rem; font-size: 13px; margin-bottom: 1.25rem; }

    @media (prefers-color-scheme: dark) { :root { --bg: #111827; } }
    .dark { --bg: #111827; }
    .dark .rdv-page { background: #111827; color: #f9fafb; }
    .dark .rdv-card, .dark .rdv-box { background: #1f2937 !important; border-color: #374151 !important; }
    .dark .rdv-title, .dark .rdv-heading { color: #f9fafb !important; }
    .dark .rdv-sub { color: #9ca3af !important; }
    .dark .rdv-label { color: #9ca3af !important; }
    .dark .rdv-input, .dark select, .dark textarea, .dark input[type=text], .dark input[type=date], .dark input[type=time] {
        background: #1f2937 !important; border-color: #374151 !important; color: #f9fafb !important;
    }
    .dark table { color: #f9fafb; }
    .dark thead { background: #1f2937; color: #9ca3af; }
    .dark tbody tr { border-color: #374151; }
    .dark tbody tr:hover { background: #1f2937; }
    .dark .bg-white { background-color: #1f2937 !important; }
    .dark .text-gray-900 { color: #f9fafb !important; }
    .dark .text-gray-700 { color: #d1d5db !important; }
    .dark .text-gray-600 { color: #9ca3af !important; }
    .dark .text-gray-500 { color: #6b7280 !important; }
    .dark .border-gray-200 { border-color: #374151 !important; }
    .dark .border-gray-100 { border-color: #374151 !important; }
    .dark .bg-gray-50 { background-color: #111827 !important; }
    .dark .bg-gray-100 { background-color: #1f2937 !important; }
</style>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<div class="rdv-page">
<div class="rdv-wrap">

    <div class="rdv-header">
        <div>
            <h1 class="rdv-title">Calendrier des disponibilités</h1>
            <p class="rdv-sub">Consultez les créneaux libres par médecin</p>
        </div>
        <a href="<?php echo e(route('rdv.create')); ?>" class="rdv-btn-primary">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
            Prendre un RDV
        </a>
    </div>

    
    <div class="rdv-card">
        <form method="GET" class="rdv-filter">
            <div>
                <label>Médecin</label>
                <select name="doctor_id" onchange="this.form.submit()">
                    <?php $__currentLoopData = $medecins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($m->id); ?>" <?php if($medecin && $medecin->id === $m->id): echo 'selected'; endif; ?>>Dr. <?php echo e($m->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label>Mois</label>
                <input type="month" name="mois" value="<?php echo e($mois); ?>" onchange="this.form.submit()">
            </div>
        </form>
    </div>

    <?php if($medecin): ?>
        <div class="doctor-banner">
            <div class="doctor-avatar"><?php echo e(strtoupper(substr($medecin->name, 0, 1))); ?></div>
            <div>
                <div class="doctor-name">Dr. <?php echo e($medecin->name); ?></div>
                <div class="doctor-role">Médecin</div>
            </div>
        </div>

        <div class="legend">
            <span><span class="leg-dot leg-green"></span> Disponible — cliquez pour réserver</span>
            <span><span class="leg-dot leg-red"></span> Créneau occupé</span>
        </div>

        <div class="cal-grid">
            <?php $__currentLoopData = $calendar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $creneaux): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $day = \Carbon\Carbon::parse($date); ?>
                <div class="cal-day">
                    <div class="cal-day-head">
                        <div class="cal-day-name"><?php echo e($day->translatedFormat('l')); ?></div>
                        <div class="cal-day-date"><?php echo e($day->format('d/m/Y')); ?></div>
                    </div>
                    <div class="cal-slots">
                        <?php $__currentLoopData = $creneaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($c['disponible']): ?>
                                <a href="<?php echo e(route('rdv.create', ['doctor_id' => $medecin->id, 'date' => $date])); ?>" class="slot-free"><?php echo e($c['heure']); ?></a>
                            <?php else: ?>
                                <span class="slot-taken"><?php echo e($c['heure']); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

</div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\YouBitech\Desktop\studies\annee3\S6\php\projet\Projet-Gestion-Application-Medical\resources\views/rdv/calendrier.blade.php ENDPATH**/ ?>