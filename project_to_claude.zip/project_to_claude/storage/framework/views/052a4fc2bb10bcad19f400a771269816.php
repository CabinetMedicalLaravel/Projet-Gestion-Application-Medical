<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-8 bg-white dark:bg-gray-900 min-h-screen font-sans text-gray-900 dark:text-gray-100 transition-colors duration-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            <!-- EN-TÊTE DYNAMIQUE -->
            <div class="mb-8 mt-4">
                <h1 class="text-3xl font-semibold text-gray-900 dark:text-gray-100">Bonjour, <?php echo e(Auth::user()->name); ?></h1>
                <p class="text-gray-500 dark:text-gray-400 mt-1">
                    <?php echo e(\Carbon\Carbon::now()->translatedFormat('l d F Y')); ?> — voici un résumé de votre espace patient
                </p>
            </div>

            <!-- SECTION 1 : STATISTIQUES DYNAMIQUES -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <!-- Bloc 1 -->
                <div class="bg-[#F8F7F4] dark:bg-gray-800 rounded-2xl p-6">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Prochain RDV</p>
                    <!-- Prochain RDV -->
                    <?php if(!empty($rdv)): ?>
                        <p class="text-3xl font-semibold text-gray-900 dark:text-gray-100 mb-1">
                            <?php echo e($rdv[0]['jour'] ?? ''); ?> <?php echo e($rdv[0]['mois'] ?? ''); ?>

                        </p>
                        <a href="<?php echo e(route('rdv.mes-rdv')); ?>" class="text-blue-600 font-medium text-sm hover:underline">
                            <?php echo e($rdv[0]['medecin'] ?? ''); ?> — <?php echo e($rdv[0]['heure'] ?? ''); ?>

                        </a>
                    <?php else: ?>
                        <p class="text-xl font-semibold text-gray-400 mb-1 mt-3">Aucun RDV prévu</p>
                    <?php endif; ?>
                </div>
                <!-- Bloc 2 -->
                <div class="bg-[#F8F7F4] dark:bg-gray-800 rounded-2xl p-6">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Total de vos RDV</p>
                    <p class="text-3xl font-semibold text-gray-900 dark:text-gray-100 mb-1"><?php echo e(count($rdv)); ?></p>
                    <p class="text-gray-500 dark:text-gray-400 text-sm">enregistrés dans le système</p>
                </div>
                <!-- Bloc 3 -->
                <div class="bg-[#F8F7F4] dark:bg-gray-800 rounded-2xl p-6">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Ordonnances</p>
                    <p class="text-3xl font-semibold text-gray-900 dark:text-gray-100 mb-1"><?php echo e($nbOrdonnances); ?></p>
                    <p class="text-gray-500 dark:text-gray-400 text-sm">téléchargeables</p>
                </div>
            </div>

            <!-- SECTION 2 : Contenu principal -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

                <!-- COLONNE GAUCHE -->
                <div class="lg:col-span-2 space-y-8">

                    <!-- Carte : Mes prochains rendez-vous -->
                    <div class="border border-gray-200 dark:border-gray-700 rounded-2xl p-6 dark:bg-gray-800/50">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-lg font-semibold dark:text-gray-100">Mes prochains rendez-vous</h2>

                            <!-- ←←← ADD THE LINK HERE -->
                            <a href="<?php echo e(route('rdv.mes-rdv')); ?>"
                                class="text-blue-600 text-sm hover:underline flex items-center gap-1">
                                Voir tous mes rendez-vous
                                <span class="text-lg leading-none">→</span>
                            </a>
                        </div>

                        <div class="space-y-6">
                            <?php $__empty_1 = true; $__currentLoopData = $rdv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rendezVous): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div
                                    class="flex items-center justify-between pb-6 border-b border-gray-100 dark:border-gray-700 last:border-0 last:pb-0">
                                    <div class="flex items-center gap-4">
                                        <div
                                            class="bg-[#EEF4FF] dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-xl p-3 flex flex-col items-center justify-center w-14 h-14">
                                            <span class="text-lg font-bold leading-none"><?php echo e($rendezVous['jour']); ?></span>
                                            <span
                                                class="text-xs font-semibold uppercase mt-1 leading-none"><?php echo e($rendezVous['mois']); ?></span>
                                        </div>
                                        <div>
                                            <p class="font-semibold text-gray-900 dark:text-gray-100 text-base"><?php echo e($rendezVous['medecin']); ?>

                                            </p>
                                            <p class="text-gray-500 dark:text-gray-400 text-sm"><?php echo e($rendezVous['specialite']); ?></p>
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <p class="font-medium text-gray-900 dark:text-gray-100 mb-1"><?php echo e($rendezVous['heure']); ?></p>
                                        <span
                                            class="bg-[#E6F6ED] text-[#0A7B45] text-xs font-semibold px-2.5 py-1 rounded-full">
                                            <?php echo e($rendezVous['statut']); ?>

                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <!-- MESSAGE AFFICHE SI LE PATIENT N'A PAS DE RDV -->
                                <div class="text-center py-10 bg-gray-50 dark:bg-gray-800 rounded-xl border border-dashed border-gray-300 dark:border-gray-600">
                                    <svg class="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                                        </path>
                                    </svg>
                                    <p class="text-gray-500 dark:text-gray-400 font-medium">Vous n'avez aucun rendez-vous à venir.</p>
                                    <a href="<?php echo e(route('rdv.create')); ?>"
                                        class="mt-3 inline-block text-blue-600 text-sm hover:underline">
                                        Prendre un rendez-vous maintenant →
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Carte : Notifications récentes -->
                    <div class="border border-gray-200 dark:border-gray-700 rounded-2xl p-6 dark:bg-gray-800/50">
                        <h2 class="text-lg font-semibold mb-6 dark:text-gray-100">Notifications récentes</h2>
                        <ul class="space-y-5">
                            <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="relative pl-6 pb-5 border-b border-gray-100 dark:border-gray-700">
                                    <span class="absolute left-0 top-1.5 w-2.5 h-2.5 bg-blue-500 rounded-full"></span>
                                    <p class="text-sm font-medium text-gray-900 dark:text-gray-100"><?php echo e($notif['message']); ?></p>
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo e($notif['date']); ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-gray-500 dark:text-gray-400 text-sm text-center py-4">Aucune notification pour le moment.</p>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <!-- COLONNE DROITE : Raccourcis (Ceux-ci restent statiques car ce sont des menus) -->
                <div class="space-y-8">
                    <div class="border border-gray-200 dark:border-gray-700 rounded-2xl p-6 dark:bg-gray-800/50">
                        <h2 class="text-lg font-semibold mb-6 dark:text-gray-100">Raccourcis</h2>
                        <div class="grid grid-cols-2 gap-4">
                            <a href="/rdv/prendre"
                                class="block bg-[#F8F7F4] dark:bg-gray-700 rounded-xl p-4 hover:bg-gray-100 dark:hover:bg-gray-600 transition">
                                <div
                                    class="bg-white dark:bg-gray-800 w-8 h-8 rounded-lg shadow-sm flex items-center justify-center mb-3">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                                        </path>
                                    </svg>
                                </div>
                                <h3 class="font-semibold text-gray-900 dark:text-gray-100 text-sm">Prendre RDV</h3>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Réserver un créneau</p>
                            </a>
                            <!-- ... J'ai gardé le premier bouton, vous pouvez remettre les 3 autres ici ... -->
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\YouBitech\Desktop\studies\annee3\S6\php\projet\Projet-Gestion-Application-Medical\resources\views/dashboard.blade.php ENDPATH**/ ?>