<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<div style="font-family:'DM Sans',sans-serif; width:100%;">

    <div class="login-logo">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
            <path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
        </svg>
    </div>

    <h1 class="login-heading">Modifier le rendez-vous</h1>
    <p class="login-sub">Changez le créneau ou le motif de votre consultation</p>

    
    <?php $dt = \Carbon\Carbon::parse($appointment->appointment_date); ?>
    <div style="background:#7F77DD0d; border:0.5px solid #7F77DD33; border-radius:12px; padding:1rem 1.1rem; margin-bottom:1.4rem; display:flex; align-items:center; gap:.9rem;">
        <div style="width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,#7F77DD,#534AB7);display:flex;align-items:center;justify-content:center;color:white;font-family:'Playfair Display',serif;font-size:1.1rem;font-weight:500;flex-shrink:0;">
            <?php echo e($dt->format('d')); ?>

        </div>
        <div>
            <div style="font-size:12px;font-weight:600;color:#7F77DD;text-transform:uppercase;letter-spacing:.3px;">RDV actuel</div>
            <div style="font-size:13.5px;color:#111;margin-top:.15rem;">Dr. <?php echo e($appointment->doctor->name); ?> — <?php echo e($dt->translatedFormat('d F Y')); ?> à <?php echo e($dt->format('H:i')); ?></div>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="login-alert"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('rdv.update', $appointment)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        
        <div class="login-field">
            <label class="login-label">Nouvelle date</label>
            <div class="login-inp-wrap">
                <svg class="login-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>
                </svg>
                <input type="date" name="date" required
                       value="<?php echo e(old('date', $date)); ?>"
                       min="<?php echo e(now()->addDay()->format('Y-m-d')); ?>"
                       class="login-input" style="padding-left:2.6rem;">
            </div>
        </div>

        
        <div class="login-field">
            <label class="login-label">Nouveau créneau</label>
            <input type="hidden" name="heure" id="heure-hidden" value="<?php echo e(old('heure', $dt->format('H:i'))); ?>">
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:.45rem;" id="creneaux-grid">
                <?php $__currentLoopData = $creneauxDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $selected = old('heure', $dt->format('H:i')) === $c; ?>
                    <button type="button"
                            onclick="selectCreneau(this,'<?php echo e($c); ?>')"
                            data-heure="<?php echo e($c); ?>"
                            style="padding:.6rem .25rem; border-radius:9px; font-size:12.5px; font-weight:500;
                                   border:0.5px solid <?php echo e($selected ? '#7F77DD' : '#e5e7eb'); ?>;
                                   background:<?php echo e($selected ? 'linear-gradient(135deg,#7F77DD,#534AB7)' : '#f9fafb'); ?>;
                                   color:<?php echo e($selected ? 'white' : '#374151'); ?>;
                                   box-shadow:<?php echo e($selected ? '0 0 0 3px #7F77DD1a' : 'none'); ?>;
                                   cursor:pointer; transition:all .18s; font-family:'DM Sans',sans-serif;">
                        <?php echo e($c); ?>

                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="login-field">
            <label class="login-label">Motif</label>
            <textarea name="reason" rows="3" required maxlength="500"
                      class="login-input"
                      style="padding:.75rem 1rem; resize:none; height:auto; line-height:1.5;"><?php echo e(old('reason', $appointment->reason)); ?></textarea>
        </div>

        <button type="submit" class="login-btn">Enregistrer les modifications</button>

        <div class="login-divider"><span>ou</span></div>

        <a href="<?php echo e(route('rdv.mes-rdv')); ?>" class="login-btn-register">Retour sans modifier</a>
    </form>
</div>

<script>
function selectCreneau(btn, heure) {
    document.querySelectorAll('#creneaux-grid button').forEach(b => {
        b.style.background = '#f9fafb';
        b.style.color = '#374151';
        b.style.borderColor = '#e5e7eb';
        b.style.boxShadow = 'none';
        b.style.transform = 'none';
    });
    btn.style.background = 'linear-gradient(135deg,#7F77DD,#534AB7)';
    btn.style.color = 'white';
    btn.style.borderColor = '#7F77DD';
    btn.style.boxShadow = '0 0 0 3px #7F77DD1a';
    btn.style.transform = 'translateY(-1px)';
    document.getElementById('heure-hidden').value = heure;
}
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\YouBitech\Desktop\studies\annee3\S6\php\projet\Projet-Gestion-Application-Medical\resources\views/rdv/modifier.blade.php ENDPATH**/ ?>