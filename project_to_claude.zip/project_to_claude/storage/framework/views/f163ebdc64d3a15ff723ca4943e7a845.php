<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<style>
    :root { --purple: #7F77DD; --purple-dark: #534AB7; --purple-light: #7F77DD1a; --bg: #F4F8FB; }
    .rdv-page { background: var(--bg); min-height: calc(100vh - 64px); padding: 2.5rem 1.5rem; font-family: 'DM Sans', sans-serif; }
    .rdv-wrap { max-width: 1100px; margin: 0 auto; }

    .rdv-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
    .rdv-title { font-family: 'Playfair Display', serif; font-size: 1.6rem; font-weight: 500; color: #111; letter-spacing: -.3px; }
    .rdv-sub { font-size: 13px; color: #6b7280; margin-top: .2rem; }

    .rdv-success { background: #ecfdf5; border: 0.5px solid #6ee7b7; color: #065f46; border-radius: 10px; padding: .75rem 1rem; font-size: 13px; margin-bottom: 1.25rem; }

    /* Nav controls */
    .plan-controls { display: flex; align-items: center; gap: .6rem; flex-wrap: wrap; }
    .plan-nav-btn {
        width: 34px; height: 34px; border-radius: 8px; border: 0.5px solid #e5e7eb;
        background: white; display: flex; align-items: center; justify-content: center;
        cursor: pointer; text-decoration: none; color: #374151; transition: border-color .15s;
    }
    .plan-nav-btn:hover { border-color: var(--purple); color: var(--purple); }
    .plan-today {
        padding: .4rem .9rem; border-radius: 8px; border: 0.5px solid #e5e7eb;
        background: white; font-size: 12.5px; font-weight: 500; color: #374151;
        text-decoration: none; transition: all .15s;
    }
    .plan-today:hover { border-color: var(--purple); color: var(--purple); }
    .plan-toggle { display: flex; border-radius: 9px; border: 0.5px solid #e5e7eb; overflow: hidden; }
    .plan-toggle a {
        padding: .45rem 1rem; font-size: 12.5px; font-weight: 500; text-decoration: none;
        color: #374151; transition: all .15s;
    }
    .plan-toggle a.active {
        background: linear-gradient(135deg, var(--purple), var(--purple-dark));
        color: white;
    }

    /* Stats */
    .stats-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: .75rem; margin-bottom: 1.5rem; }
    .stat-card { background: white; border-radius: 12px; border: 0.5px solid #e5e7eb; padding: 1rem; text-align: center; }
    .stat-num { font-family: 'Playfair Display', serif; font-size: 1.6rem; font-weight: 500; color: #111; }
    .stat-label { font-size: 11.5px; color: #6b7280; margin-top: .2rem; }

    /* Jour list */
    .rdv-list { display: flex; flex-direction: column; gap: .65rem; }
    .rdv-item { background: white; border-radius: 13px; border: 0.5px solid #e5e7eb; padding: 1rem 1.3rem; display: flex; align-items: center; gap: 1.1rem; transition: box-shadow .2s; }
    .rdv-item:hover { box-shadow: 0 4px 16px rgba(0,0,0,.06); }
    .rdv-time { font-family: 'Playfair Display', serif; font-size: 1.2rem; font-weight: 500; color: var(--purple); width: 56px; flex-shrink: 0; }
    .rdv-divider { width: 1px; height: 40px; background: #e5e7eb; flex-shrink: 0; }
    .rdv-patient { font-weight: 600; font-size: 13.5px; color: #111; }
    .rdv-reason { font-size: 12px; color: #6b7280; margin-top: .2rem; font-style: italic; }

    .badge { display: inline-flex; align-items: center; gap: .3rem; font-size: 11.5px; font-weight: 500; padding: .2rem .65rem; border-radius: 100px; }
    .badge-dot { width: 5px; height: 5px; border-radius: 50%; }
    .badge-orange { background: #fff7ed; color: #c2410c; } .badge-orange .badge-dot { background: #f97316; }
    .badge-purple { background: var(--purple-light); color: var(--purple-dark); } .badge-purple .badge-dot { background: var(--purple); }
    .badge-green  { background: #ecfdf5; color: #065f46; }  .badge-green .badge-dot  { background: #10b981; }
    .badge-gray   { background: #f9fafb; color: #6b7280; }  .badge-gray .badge-dot   { background: #9ca3af; }

    .btn-sm {
        font-size: 12px; padding: .4rem .8rem; border-radius: 7px; border: none;
        cursor: pointer; font-family: 'DM Sans', sans-serif; font-weight: 500; transition: all .15s;
    }
    .btn-confirm { background: var(--purple-light); color: var(--purple-dark); }
    .btn-confirm:hover { background: var(--purple); color: white; }
    .btn-done { background: #ecfdf5; color: #065f46; }
    .btn-done:hover { background: #10b981; color: white; }

    /* Semaine grid */
    .week-grid { display: grid; grid-template-columns: repeat(7,1fr); gap: .6rem; }
    .week-col { background: white; border-radius: 13px; border: 0.5px solid #e5e7eb; overflow: hidden; }
    .week-col.today { border-color: var(--purple); box-shadow: 0 0 0 2px var(--purple-light); }
    .week-head { padding: .6rem .5rem; text-align: center; border-bottom: 0.5px solid #e5e7eb; background: #f9fafb; }
    .week-col.today .week-head { background: linear-gradient(135deg, var(--purple), var(--purple-dark)); color: white; border-bottom-color: var(--purple-dark); }
    .week-dow { font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: .4px; }
    .week-num { font-family: 'Playfair Display', serif; font-size: 1.2rem; font-weight: 500; }
    .week-body { padding: .5rem; min-height: 100px; display: flex; flex-direction: column; gap: .35rem; }
    .week-slot { background: var(--purple-light); border: 0.5px solid #7F77DD33; border-radius: 7px; padding: .35rem .5rem; }
    .week-slot-time { font-size: 11px; font-weight: 700; color: var(--purple); }
    .week-slot-name { font-size: 11px; color: #374151; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .week-empty { text-align: center; font-size: 11.5px; color: #d1d5db; padding-top: 1.5rem; }

    .rdv-empty { background: white; border-radius: 14px; border: 0.5px solid #e5e7eb; padding: 3.5rem 2rem; text-align: center; }

    @media (prefers-color-scheme: dark) { :root { --bg: #111827; } }
    .dark { --bg: #111827; }
    .dark .rdv-page { background: #111827; color: #f9fafb; }
    .dark .rdv-card, .dark .rdv-box { background: #1f2937 !important; border-color: #374151 !important; }
    .dark .rdv-title, .dark .rdv-heading { color: #f9fafb !important; }
    .dark .rdv-sub { color: #9ca3af !important; }
    .dark .rdv-label { color: #9ca3af !important; }
    .dark .rdv-input, .dark select, .dark textarea, .dark input[type=text], .dark input[type=date], .dark input[type=time] {
        background: #1f2937 !important; border-color: #374151 !important; color: #f9fafb !important;
    }
    .dark table { color: #f9fafb; }
    .dark thead { background: #1f2937; color: #9ca3af; }
    .dark tbody tr { border-color: #374151; }
    .dark tbody tr:hover { background: #1f2937; }
    .dark .bg-white { background-color: #1f2937 !important; }
    .dark .text-gray-900 { color: #f9fafb !important; }
    .dark .text-gray-700 { color: #d1d5db !important; }
    .dark .text-gray-600 { color: #9ca3af !important; }
    .dark .text-gray-500 { color: #6b7280 !important; }
    .dark .border-gray-200 { border-color: #374151 !important; }
    .dark .border-gray-100 { border-color: #374151 !important; }
    .dark .bg-gray-50 { background-color: #111827 !important; }
    .dark .bg-gray-100 { background-color: #1f2937 !important; }
</style>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

<div class="rdv-page">
<div class="rdv-wrap">

    <div class="rdv-header">
        <div>
            <h1 class="rdv-title">Mon planning</h1>
            <p class="rdv-sub">
                <?php if($vue === 'semaine'): ?> Semaine du <?php echo e($date->copy()->startOfWeek()->format('d/m')); ?> au <?php echo e($date->copy()->endOfWeek()->format('d/m/Y')); ?>

                <?php else: ?> <?php echo e(ucfirst($date->translatedFormat('l d F Y'))); ?>

                <?php endif; ?>
            </p>
        </div>

        <div class="plan-controls">
            <?php
                $prev = $vue === 'semaine' ? $date->copy()->subWeek()->format('Y-m-d') : $date->copy()->subDay()->format('Y-m-d');
                $next = $vue === 'semaine' ? $date->copy()->addWeek()->format('Y-m-d') : $date->copy()->addDay()->format('Y-m-d');
            ?>
            <a href="<?php echo e(route('rdv.planning', ['vue'=>$vue,'date'=>$prev])); ?>" class="plan-nav-btn">
                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg>
            </a>
            <a href="<?php echo e(route('rdv.planning', ['vue'=>$vue,'date'=>now()->format('Y-m-d')])); ?>" class="plan-today">Aujourd'hui</a>
            <a href="<?php echo e(route('rdv.planning', ['vue'=>$vue,'date'=>$next])); ?>" class="plan-nav-btn">
                <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
            </a>
            <div class="plan-toggle">
                <a href="<?php echo e(route('rdv.planning', ['vue'=>'jour','date'=>$date->format('Y-m-d')])); ?>" class="<?php echo e($vue==='jour'?'active':''); ?>">Jour</a>
                <a href="<?php echo e(route('rdv.planning', ['vue'=>'semaine','date'=>$date->format('Y-m-d')])); ?>" class="<?php echo e($vue==='semaine'?'active':''); ?>">Semaine</a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="rdv-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($vue === 'jour'): ?>
        <?php $rdvList = $rdvs; ?>
        <?php if($rdvList->isEmpty()): ?>
            <div class="rdv-empty">
                <svg style="width:48px;height:48px;color:#d1d5db;margin:0 auto 1rem;" fill="none" stroke="currentColor" stroke-width="1" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
                <p style="font-size:14px;color:#6b7280;">Aucun rendez-vous ce jour</p>
            </div>
        <?php else: ?>
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-num"><?php echo e($rdvList->count()); ?></div><div class="stat-label">Total</div></div>
                <div class="stat-card"><div class="stat-num" style="color:#f97316;"><?php echo e($rdvList->where('status','en_attente')->count()); ?></div><div class="stat-label">En attente</div></div>
                <div class="stat-card"><div class="stat-num" style="color:var(--purple);"><?php echo e($rdvList->where('status','confirme')->count()); ?></div><div class="stat-label">Confirmés</div></div>
                <div class="stat-card"><div class="stat-num" style="color:#059669;"><?php echo e($rdvList->where('status','termine')->count()); ?></div><div class="stat-label">Terminés</div></div>
            </div>

            <div class="rdv-list">
                <?php $__currentLoopData = $rdvList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $dt = \Carbon\Carbon::parse($rdv->appointment_date);
                        $bc = match($rdv->status) { 'en_attente'=>'badge-orange','confirme'=>'badge-purple','termine'=>'badge-green',default=>'badge-gray' };
                        $lbl = ['en_attente'=>'En attente','confirme'=>'Confirmé','termine'=>'Terminé','annule'=>'Annulé'][$rdv->status] ?? $rdv->status;
                    ?>
                    <div class="rdv-item">
                        <div class="rdv-time"><?php echo e($dt->format('H:i')); ?></div>
                        <div class="rdv-divider"></div>
                        <div style="flex:1;">
                            <div style="display:flex;align-items:center;gap:.6rem;flex-wrap:wrap;">
                                <span class="rdv-patient"><?php echo e($rdv->patient->name); ?></span>
                                <span class="badge <?php echo e($bc); ?>"><span class="badge-dot"></span><?php echo e($lbl); ?></span>
                            </div>
                            <?php if($rdv->reason): ?><div class="rdv-reason">"<?php echo e(Str::limit($rdv->reason,60)); ?>"</div><?php endif; ?>
                        </div>
                        <?php if($rdv->status === 'en_attente'): ?>
                            <form method="POST" action="<?php echo e(route('rdv.statut', $rdv)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="status" value="confirme">
                                <button type="submit" class="btn-sm btn-confirm">Confirmer</button>
                            </form>
                        <?php elseif($rdv->status === 'confirme'): ?>
                            <form method="POST" action="<?php echo e(route('rdv.statut', $rdv)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="status" value="termine">
                                <button type="submit" class="btn-sm btn-done">Terminer</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        
        <?php
            $jours = [];
            $start = $date->copy()->startOfWeek();
            for ($i = 0; $i < 7; $i++) $jours[] = $start->copy()->addDays($i);
        ?>
        <div class="week-grid">
            <?php $__currentLoopData = $jours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $ds = $jour->toDateString();
                    $rdvJour = $rdvs[$ds] ?? collect();
                    $isToday = $jour->isToday();
                ?>
                <div class="week-col <?php echo e($isToday ? 'today' : ''); ?>">
                    <div class="week-head">
                        <div class="week-dow"><?php echo e($jour->translatedFormat('D')); ?></div>
                        <div class="week-num"><?php echo e($jour->format('d')); ?></div>
                    </div>
                    <div class="week-body">
                        <?php if($rdvJour->isEmpty()): ?>
                            <div class="week-empty">—</div>
                        <?php else: ?>
                            <?php $__currentLoopData = $rdvJour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="week-slot">
                                    <div class="week-slot-time"><?php echo e(\Carbon\Carbon::parse($rdv->appointment_date)->format('H:i')); ?></div>
                                    <div class="week-slot-name"><?php echo e($rdv->patient->name); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

</div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\YouBitech\Desktop\studies\annee3\S6\php\projet\Projet-Gestion-Application-Medical\resources\views/rdv/planning.blade.php ENDPATH**/ ?>